<?php
 echo do_shortcode('[block id="cart-related-product"]');

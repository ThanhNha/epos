
<?php echo do_shortcode('[block id="product-categories"]') ?>
